import os
import re
import winreg
import zipfile
import requests

base_url = 'http://npm.taobao.org/mirrors/chromedriver/'
version_re = re.compile(r'^[1-9]\d*\.\d*.\d*')  


def getChromeVersion():

    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, 'Software\\Google\\Chrome\\BLBeacon')
        value, t = winreg.QueryValueEx(key, 'version')
        return version_re.findall(value)[0]  
    except WindowsError as e:
        return "1.1.1"


def getChromeDriverVersion():
    outstd2 = os.popen('chromedriver --version').read()
    try:
        version = outstd2.split(' ')[1]
        version = ".".join(version.split(".")[:-1])
        return version
    except Exception as e:
        return "0.0.0"


def getLatestChromeDriver(version):

    url = f"{base_url}LATEST_RELEASE_{version}"
    latest_version = requests.get(url).text
    print(f"The version of the chrome driver is: {latest_version}")
    print("Start downloading the compatible chrome driver...")
    download_url = f"{base_url}{latest_version}/chromedriver_win32.zip"
    file = requests.get(download_url)
    with open("chromedriver.zip", 'wb') as zip_file:  
        zip_file.write(file.content)
    print("donwload done.")
    f = zipfile.ZipFile("chromedriver.zip", 'r')
    for file in f.namelist():
        f.extract(file)
    print("unzip done.")


def checkChromeDriverUpdate():
    chrome_version = getChromeVersion()
    print(f'the current chrome version: {chrome_version}')
    driver_version = getChromeDriverVersion()
    print(f'the current chromedriver version: {driver_version}')
    if chrome_version == driver_version:
        print("already the compatible version.")
        return
    print("updating>>>")
    try:
        getLatestChromeDriver(chrome_version)
        print("downloading the chromedriver succeed!")
    except requests.exceptions.Timeout:
        print("downloading the chromedriver failed, please check your network and retry！")
    except Exception as e:
        print(f"downloading the chromedriver failed with unexpected error: {e}")


if __name__ == "__main__":
    checkChromeDriverUpdate()

