import sys
from selenium import webdriver
from selenium.webdriver.chrome.service import Service


def kick(username, password):

    chrome_options = webdriver.ChromeOptions() 
    chrome_options.add_experimental_option("excludeSwitches", ["enable-logging","enable-automation"])
    
    config_url = "https://mail.163.com/"
    driver_path = "./driver/chromedriver.exe"
    global driver
    #driver = webdriver.Chrome(driver_path,options=chrome_options)
    driver = webdriver.Chrome(service=Service(driver_path), options=chrome_options)
    
    driver.implicitly_wait(5)
    driver.maximize_window()

    driver.get(config_url)

    driver.switch_to.frame(driver.find_element("xpath",'//*[@id="loginDiv"]/iframe'))

    account = driver.find_element("xpath",'//input[@name="email"]')
    account.clear()
    account.send_keys(username)

    passwd = driver.find_element("xpath",'//input[@name="password"]')
    passwd.clear()
    passwd.send_keys(password)

    click_button = driver.find_element('id', 'dologin')
    click_button.click()



if __name__ == '__main__':

    # usernmae: sys.argv[1]
    # password: sys.argv[2]
    kick(sys.argv[1], sys.argv[2])



